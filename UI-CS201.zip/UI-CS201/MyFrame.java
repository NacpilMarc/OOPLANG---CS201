
/**
 * Write a description of class MyFrame here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

import javax.swing.*;

public class MyFrame extends JFrame
{
    public static void main (String []args){
        new MyFrame();
    }
    
    public MyFrame(){
        
        setSize(640, 400);
        setLocation(500,200);
        setTitle("MARC NACPIL - CS201");
        setVisible(true);
        add(new JButton("1"));
        
    }
}
