
/**
 * Write a description of class MyWindow here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

import javax.swing.*;

public class MyWindow
{
    public static void main (String []args){
        JFrame window = new JFrame();
        window.setTitle("MARC NACPIL CS-201");
        window.setVisible(true);
        //window.setSize(640, 400);
        //window.setLocation(500, 200);
        window.setBounds(0,0,800,300);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        window.add(new JTextField("   "));
        window.add(new JButton("Click Me Baby"));
        
        
    }
}
