
/**
 * Write a description of class Stopwatch here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class Stopwatch extends JFrame
{
    long startTime;
    long stopTime;
    double elapsedTime;
    
    JButton startButton = new JButton();
    JButton stopButton = new JButton();
    JButton exitButton = new JButton();
    
    JLabel startLabel = new JLabel();
    JLabel stopLabel = new JLabel();
    JLabel elapsedLabel = new JLabel();
    
    JTextField startJTextField = new JTextField();
    JTextField stopJTextField = new JTextField();
    JTextField elapsedJTextField = new JTextField();
    
    public static void main (String[]args){
        new Stopwatch().show();
    }
    
    private void exitForm(WindowEvent e){
        JFrame f;
        f = new JFrame();
        JOptionPane.showMessageDialog(f, "Existing Module");
    }
    
    private void startButtonActionPerformed(ActionEvent e){
        JFrame f;
        f = new JFrame();
        JOptionPane.showMessageDialog(f, "Start Timer Initiated");
    }
    
    private void stopButtonActionPerformed(ActionEvent e){
        JFrame f;
        f = new JFrame();
        JOptionPane.showMessageDialog(f, "Stop Timer Initiated");
    }
    
    private void exitButtonActionPerformed(ActionEvent e){
        JFrame f;
        f = new JFrame();
        JOptionPane.showMessageDialog(f, "Thank you for using our Program");
        System.exit(0);
    }

    public Stopwatch(){
        setTitle("Stopwatch Application");
        setSize(300,100);
        setLocation(600,400);
        //add (new JLabel("Hello"));
        //add(new JLabel("Start Label"));
        //add(new JLabel("Stop Label"));
        //add(new JLabel("Elapsed Label"));
        
        getContentPane().setLayout(new GridBagLayout());
        
        GridBagConstraints gridConstraints = new GridBagConstraints();
        
        //JBUTTON
        startButton.setText("Start Timer");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        getContentPane().add(startButton, gridConstraints);
        
        startButton.addActionListener(new ActionListener(){
           public void actionPerformed(ActionEvent e){
               startButtonActionPerformed(e);
           }
        });
        
        stopButton.setText("Stop Timer");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 1;
        getContentPane().add(stopButton, gridConstraints);
        
        stopButton.addActionListener(new ActionListener(){
           public void actionPerformed(ActionEvent e){
               stopButtonActionPerformed(e);
           }
        });
    
        exitButton.setText("Exit Timer");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 2;
        getContentPane().add(exitButton, gridConstraints);
        
        exitButton.addActionListener(new ActionListener(){
           public void actionPerformed(ActionEvent e){
               exitButtonActionPerformed(e);
           }
        });
        
        //JLABEL
        startLabel.setText("    Start time  ");
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 0;
        getContentPane().add(startLabel, gridConstraints);
        
        stopLabel.setText("     Stop time   ");
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 1;
        getContentPane().add(stopLabel, gridConstraints);
        
        elapsedLabel.setText("      Elapsed time (sec)      ");
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 2;
        getContentPane().add(elapsedLabel, gridConstraints);
        
        //JTEXTFIELD
        startJTextField.setText("");
        startJTextField.setColumns(15);
        gridConstraints.gridx = 2;
        gridConstraints.gridy = 0;
        getContentPane().add(startJTextField, gridConstraints);
        
        stopJTextField.setText("");
        stopJTextField.setColumns(15);
        gridConstraints.gridx = 2;
        gridConstraints.gridy = 1;
        getContentPane().add(stopJTextField, gridConstraints);
        
        elapsedJTextField.setText("");
        elapsedJTextField.setColumns(15);
        gridConstraints.gridx = 2;
        gridConstraints.gridy = 2;
        getContentPane().add(elapsedJTextField, gridConstraints);
        
        addWindowListener(new WindowAdapter(){
            public void windowClosing(WindowEvent e){
                exitForm(e);
            }
        });
        
        pack();
    }
}
