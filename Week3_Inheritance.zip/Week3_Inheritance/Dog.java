
/**
 * Write a description of class Dog here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

public class Dog extends JFrame
{
    //breed, tag number, color
    String Breed = "Askal baby";
    String Tag_Number = "NO.1";
    String Color = "Golden Black";
    
    JLabel BreedLabel = new JLabel();
    JLabel TagNumberLabel = new JLabel();
    JLabel ColorLabel = new JLabel();
    
    JTextField BreedTF = new JTextField();
    JTextField TagNumberTF = new JTextField();
    JTextField ColorTF = new JTextField();
    
    JButton PrintBTN = new JButton();
    JButton ExitBTN = new JButton();
    
    public static void main (String[]args){
        Dog myDog = new Dog();
        myDog.show();
    }

    public void PrintInfo(ActionEvent e){
        
        JOptionPane.showMessageDialog(null,"Breed :                " + BreedTF.getText() + "\n" + "Tag Number :    " + TagNumberTF.getText() + "\n" + "Color :                 " + ColorTF.getText(),"Dog's Information", JOptionPane.INFORMATION_MESSAGE);

    }
    
    public void Exit(ActionEvent e){
        
        JOptionPane.showMessageDialog(null,"Thank You!");
        System.exit(0);
    }
    
    public Dog(){
        
        setTitle("This is My Dog");
        setSize(500,500);
        setLocation(600,300);
        
        getContentPane().setLayout(new GridBagLayout());
        GridBagConstraints gridCons = new GridBagConstraints();
        
        BreedLabel.setText("Breed : ");
        gridCons.gridx = 0;
        gridCons.gridy = 0;
        getContentPane().add(BreedLabel, gridCons);
        
        TagNumberLabel.setText("Tag Number : ");
        gridCons.gridx = 0;
        gridCons.gridy = 1;
        getContentPane().add(TagNumberLabel,  gridCons);
        
        ColorLabel.setText("Color : ");
        gridCons.gridx = 0;
        gridCons.gridy = 2;
        getContentPane().add(ColorLabel, gridCons);
        
        BreedTF.setColumns(8);
        gridCons.gridx = 1;
        gridCons.gridy = 0;
        getContentPane().add(BreedTF,  gridCons);
        
        TagNumberTF.setColumns(8);
        gridCons.gridx = 1;
        gridCons.gridy = 1;
        getContentPane().add(TagNumberTF,  gridCons);
        
        ColorTF.setColumns(8);
        gridCons.gridx = 1;
        gridCons.gridy = 2;
        getContentPane().add(ColorTF,  gridCons);
        
        PrintBTN.setText("Print Info");
        gridCons.gridx = 0;
        gridCons.gridy = 4;
        getContentPane().add(PrintBTN,  gridCons);
        
        PrintBTN.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                PrintInfo(e);
            }
        });
        
        ExitBTN.setText("Exit");
        gridCons.gridx = 1;
        gridCons.gridy = 4;
        getContentPane().add(ExitBTN,  gridCons);
        
        ExitBTN.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                Exit(e);
            }
        });
 
        pack();
    }
}
