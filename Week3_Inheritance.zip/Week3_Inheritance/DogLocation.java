
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

public class DogLocation extends Dog
{
    String Location = "HAU";
    
    public static void main (String[]args){
        new Dog().show();
    }
    
}
