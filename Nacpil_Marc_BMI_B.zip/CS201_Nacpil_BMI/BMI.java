
/**
 * Write a description of class BMI here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

import java.awt.event.*;
import java.awt.*;
import javax.swing.*;

public class BMI extends JFrame
{
    JLabel LBHeight = new JLabel();
    JLabel LBWeight = new JLabel();
    JLabel LBPounds = new JLabel();
    JLabel LBFoot = new JLabel();
    
    JTextField TFHeight = new JTextField();
    JTextField TFWeight = new JTextField();
    
    JButton BTNCompute = new JButton();
    JButton BTNExit = new JButton();
    JButton BTNClear = new JButton();
    
    public static void main (String[]args){
        new BMI().show();
    }
    
    private void BTNCompute(ActionEvent e){
    JFrame f;
    f = new JFrame();
    
    String height = TFHeight.getText();
    String weight = TFWeight.getText();   
    
    double dob_height = Double.parseDouble(height);
    double dob_weight = Double.parseDouble(weight);
    
    double height_meters = dob_height / 3.281;  //foot to meters
    
    double heightval = height_meters * height_meters;
    
    double BMIVal = dob_weight / heightval;
    
    JOptionPane.showMessageDialog(f, "Your BMI is : " + String.format("%.2f", BMIVal));
    
    System.exit(0);
    }    
    
    private void BTNExit(ActionEvent e){
    JFrame f;
    f = new JFrame();
    JOptionPane.showMessageDialog(f, "Thank You for Usign our Program!");
    System.exit(0);
    }  
    
    private void BTNClear(ActionEvent e){
    TFHeight.setText("   ");
    TFWeight.setText("   ");
    }  
    
    public BMI(){
    
        setTitle("Body Mass Index Calculator");
        setSize(500,500);
        setLocation(500,200);
        
        getContentPane().setLayout(new GridBagLayout());
        GridBagConstraints gridCons = new GridBagConstraints();
        
        LBHeight.setText("  Height :  ");
        gridCons.gridx = 0;
        gridCons.gridy = 0;
        getContentPane().add(LBHeight, gridCons);
        
        LBFoot.setText("  Foot  ");
        gridCons.gridx = 2;
        gridCons.gridy = 0;
        getContentPane().add(LBFoot, gridCons);
        
        LBWeight.setText("  Weight :  ");
        gridCons.gridx = 0;
        gridCons.gridy = 1;
        getContentPane().add(LBWeight, gridCons);
        
        LBPounds.setText("  Kilograms  ");
        gridCons.gridx = 2;
        gridCons.gridy = 1;
        getContentPane().add(LBPounds, gridCons);
        
        TFHeight.setText("   ");
        TFHeight.setColumns(10);
        gridCons.gridx = 1;
        gridCons.gridy = 0;
        getContentPane().add(TFHeight, gridCons);
        
        TFWeight.setText("   ");
        TFWeight.setColumns(10);
        gridCons.gridx = 1;
        gridCons.gridy = 1;
        getContentPane().add(TFWeight, gridCons);
        
        BTNCompute.setText("  Compute BMI  ");
        gridCons.gridx = 0;
        gridCons.gridy = 2;
        getContentPane().add(BTNCompute, gridCons);
        
        BTNCompute.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                BTNCompute(e);
            }
        });
        
        BTNExit.setText("   Exit    ");
        gridCons.gridx = 2;
        gridCons.gridy = 2;
        getContentPane().add(BTNExit, gridCons);
        
        BTNExit.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                BTNExit(e);
            }
        });
        
        BTNClear.setText("  Clear   ");
        gridCons.gridx = 1;
        gridCons.gridy = 2;
        getContentPane().add(BTNClear, gridCons);
        
        BTNClear.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                BTNClear(e);
            }
        });
        
        pack();
    }
}
